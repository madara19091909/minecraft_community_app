import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../auth/presentation/auth_controller.dart';

/// Minimal profile for Phase 1: identity + sign out. Full profile in Phase 2.
class ProfileScreen extends ConsumerWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final auth = ref.watch(authControllerProvider);
    final p = auth.profile;
    return Scaffold(
      appBar: AppBar(title: const Text('Profile')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Center(
            child: CircleAvatar(
              radius: 44,
              backgroundImage: p?.avatarUrl != null ? NetworkImage(p!.avatarUrl!) : null,
              child: p?.avatarUrl == null ? const Icon(Icons.person, size: 44) : null,
            ),
          ),
          const SizedBox(height: 14),
          Center(child: Text(p?.displayName ?? '', style: Theme.of(context).textTheme.headlineSmall)),
          Center(child: Text('@${p?.username ?? ''} · ${p?.roleKey ?? ''}')),
          const SizedBox(height: 32),
          OutlinedButton.icon(
            onPressed: auth.signOut,
            icon: const Icon(Icons.logout),
            label: const Text('Sign out'),
          ),
        ],
      ),
    );
  }
}
