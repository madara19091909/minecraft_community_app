import 'package:flutter/material.dart';
import '../../shell/presentation/placeholder_tab.dart';

class CommunitiesScreen extends StatelessWidget {
  const CommunitiesScreen({super.key});
  @override
  Widget build(BuildContext context) => const PlaceholderTab(
      title: 'Communities', icon: Icons.groups, message: 'Communities arrive in Phase 4.');
}
