import 'package:flutter/material.dart';
import '../../shell/presentation/placeholder_tab.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});
  @override
  Widget build(BuildContext context) => const PlaceholderTab(
      title: 'Home', icon: Icons.dynamic_feed, message: 'The feed arrives in Phase 3.');
}
