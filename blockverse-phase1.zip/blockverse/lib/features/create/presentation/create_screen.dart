import 'package:flutter/material.dart';
import '../../shell/presentation/placeholder_tab.dart';

class CreateScreen extends StatelessWidget {
  const CreateScreen({super.key});
  @override
  Widget build(BuildContext context) => const PlaceholderTab(
      title: 'Create', icon: Icons.add_box, message: 'Post creation arrives in Phase 3.');
}
