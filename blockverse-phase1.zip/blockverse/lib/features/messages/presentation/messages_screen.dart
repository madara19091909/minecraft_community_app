import 'package:flutter/material.dart';
import '../../shell/presentation/placeholder_tab.dart';

class MessagesScreen extends StatelessWidget {
  const MessagesScreen({super.key});
  @override
  Widget build(BuildContext context) => const PlaceholderTab(
      title: 'Messages', icon: Icons.chat_bubble, message: 'Direct messages arrive in Phase 5.');
}
