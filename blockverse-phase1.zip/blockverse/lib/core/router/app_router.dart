import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../features/auth/presentation/access_denied_screen.dart';
import '../../features/auth/presentation/auth_controller.dart';
import '../../features/auth/presentation/login_screen.dart';
import '../../features/communities/presentation/communities_screen.dart';
import '../../features/create/presentation/create_screen.dart';
import '../../features/home/presentation/home_screen.dart';
import '../../features/messages/presentation/messages_screen.dart';
import '../../features/profile/presentation/profile_screen.dart';
import '../../features/shell/presentation/main_shell.dart';
import '../widgets/loading_view.dart';

abstract class Routes {
  static const splash = '/splash';
  static const login = '/login';
  static const denied = '/access-denied';
  static const home = '/home';
  static const communities = '/communities';
  static const create = '/create';
  static const messages = '/messages';
  static const profile = '/profile';
}

final routerProvider = Provider<GoRouter>((ref) {
  final auth = ref.read(authControllerProvider);

  return GoRouter(
    initialLocation: Routes.splash,
    refreshListenable: auth,
    redirect: (context, state) {
      final loc = state.matchedLocation;
      final String target;
      switch (auth.phase) {
        case AuthPhase.loading:
          target = Routes.splash;
        case AuthPhase.signedOut:
          target = Routes.login;
        case AuthPhase.error:
          target = Routes.denied;
        case AuthPhase.ready:
          if (!auth.canAccessApp) {
            target = Routes.denied;
          } else if ([Routes.splash, Routes.login, Routes.denied].contains(loc)) {
            target = Routes.home;
          } else {
            target = loc;
          }
      }
      return target == loc ? null : target;
    },
    routes: [
      GoRoute(
        path: Routes.splash,
        builder: (_, __) => const Scaffold(body: LoadingView()),
      ),
      GoRoute(path: Routes.login, builder: (_, __) => const LoginScreen()),
      GoRoute(path: Routes.denied, builder: (_, __) => const AccessDeniedScreen()),
      StatefulShellRoute.indexedStack(
        builder: (_, __, shell) => MainShell(navigationShell: shell),
        branches: [
          StatefulShellBranch(routes: [
            GoRoute(path: Routes.home, builder: (_, __) => const HomeScreen()),
          ]),
          StatefulShellBranch(routes: [
            GoRoute(path: Routes.communities, builder: (_, __) => const CommunitiesScreen()),
          ]),
          StatefulShellBranch(routes: [
            GoRoute(path: Routes.create, builder: (_, __) => const CreateScreen()),
          ]),
          StatefulShellBranch(routes: [
            GoRoute(path: Routes.messages, builder: (_, __) => const MessagesScreen()),
          ]),
          StatefulShellBranch(routes: [
            GoRoute(path: Routes.profile, builder: (_, __) => const ProfileScreen()),
          ]),
        ],
      ),
    ],
  );
});
